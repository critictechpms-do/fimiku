'use client';
import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    const router = useRouter();
    const pathname = usePathname();
    const [isAuthorized, setIsAuthorized] = useState(false);

    useEffect(() => {
        const token = localStorage.getItem('admin_access_token');
        const isLoginPage = pathname === '/admin/login';

        if (!token && !isLoginPage) {
            router.replace('/admin/login');
        } else if (token && isLoginPage) {
            router.replace('/admin/dashboard');
        } else {
            setIsAuthorized(true);
        }
    }, [pathname, router]);

    if (!isAuthorized) return <div className="min-h-screen bg-[#FAF6FD] flex items-center justify-center">Loading...</div>;

    if (pathname === '/admin/login') {
        return <>{children}</>;
    }

    return (
        <div className="flex min-h-screen bg-[#FAF6FD] text-[#1E1A29]">
            <div className="w-64 bg-white border-r border-[#EFEBFA] hidden md:block" />
            <main className="flex-1 p-8">
                {children}
            </main>
        </div>
    );
}
