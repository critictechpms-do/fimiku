'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';
import { Lock } from 'lucide-react';

export default function AdminLogin() {
    const router = useRouter();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const res = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/store/admin/api/token/`, {
                username,
                password
            });
            
            localStorage.setItem('admin_access_token', res.data.access);
            localStorage.setItem('admin_refresh_token', res.data.refresh);
            
            router.push('/admin/dashboard');
        } catch (err: any) {
            setError(err.response?.data?.detail || 'Invalid admin credentials');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-[#FAF6FD]">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-[#EFEBFA] w-full max-w-md">
                <div className="flex flex-col items-center mb-8">
                    <div className="w-12 h-12 bg-[#8E57F5]/10 rounded-full flex items-center justify-center mb-4">
                        <Lock className="text-[#8E57F5] w-6 h-6" />
                    </div>
                    <h1 className="text-2xl font-bold text-[#1E1A29]">FIMIKU Admin</h1>
                    <p className="text-sm text-gray-500 mt-1">Sign in to manage your store</p>
                </div>
                {error && (
                    <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-6 border border-red-100">
                        {error}
                    </div>
                )}
                <form onSubmit={handleLogin} className="space-y-5">
                    <div>
                        <label className="block text-sm font-medium text-[#1E1A29] mb-1">Username</label>
                        <input
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full px-4 py-2 border border-[#EFEBFA] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8E57F5]/20 focus:border-[#8E57F5] transition-colors"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-[#1E1A29] mb-1">Password</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 border border-[#EFEBFA] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8E57F5]/20 focus:border-[#8E57F5] transition-colors"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-[#8E57F5] hover:bg-[#9764FA] text-white font-medium py-2.5 rounded-lg transition-colors disabled:opacity-70"
                    >
                        {loading ? 'Authenticating...' : 'Sign In'}
                    </button>
                </form>
            </div>
        </div>
    );
}
