import axios from 'axios';

const axiosAdmin = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api',
    headers: {
        'Content-Type': 'application/json',
    },
});

axiosAdmin.interceptors.request.use((config) => {
    if (typeof window !== 'undefined') {
        const token = localStorage.getItem('admin_access_token');
        if (token && config.headers) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
});

axiosAdmin.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            if (typeof window !== 'undefined') {
                localStorage.removeItem('admin_access_token');
                localStorage.removeItem('admin_refresh_token');
                window.location.href = '/admin/login';
            }
        }
        return Promise.reject(error);
    }
);

export default axiosAdmin;
