
from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=120, unique=True)
    slug = models.SlugField(max_length=140, unique=True)
    description = models.TextField(blank=True)
    image_url = models.URLField(max_length=500, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Product(models.Model):
    category = models.ForeignKey(
        Category,
        related_name="products",
        on_delete=models.CASCADE,
    )
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True)
    description = models.TextField()
    features = models.JSONField(
        default=list,
        help_text="List of feature bullet points",
    )
    material = models.CharField(
        max_length=150,
        default="100% Food-Grade Silicone (BPA, PVC, Phthalate Free)",
    )
    target_age = models.CharField(max_length=50, default="3m+")
    price = models.DecimalField(max_digits=10, decimal_places=2)
    discount_price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    stock = models.PositiveIntegerField(default=50)
    sku = models.CharField(max_length=60, unique=True)
    image_url = models.URLField(max_length=500)
    additional_images = models.JSONField(default=list, blank=True)
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.name

    @property
    def final_price(self):
        return self.discount_price if self.discount_price else self.price

    @property
    def is_in_stock(self):
        return self.stock > 0

    @property
    def average_rating(self):
        reviews = self.reviews.all()
        if reviews.exists():
            return round(
                sum(review.rating for review in reviews) / reviews.count(),
                1,
            )
        return 5.0


class Cart(models.Model):
    session_key = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        unique=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Cart #{self.id} ({self.session_key})"


class CartItem(models.Model):
    cart = models.ForeignKey(
        Cart,
        related_name="items",
        on_delete=models.CASCADE,
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
    )
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ("cart", "product")

    def subtotal(self):
        return self.product.final_price * self.quantity


class Wishlist(models.Model):
    session_key = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        unique=True,
    )
    products = models.ManyToManyField(
        Product,
        related_name="wishlisted_by",
        blank=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Wishlist ({self.session_key})"


class Coupon(models.Model):
    DISCOUNT_TYPES = (
        ("PERCENTAGE", "Percentage Discount"),
        ("FIXED", "Fixed Amount"),
    )

    code = models.CharField(max_length=50, unique=True)
    discount_type = models.CharField(
        max_length=20,
        choices=DISCOUNT_TYPES,
        default="PERCENTAGE",
    )
    value = models.DecimalField(max_digits=10, decimal_places=2)
    min_order_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
    )
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.code


class Order(models.Model):
    STATUS_CHOICES = (
        ("PENDING", "Pending Payment"),
        ("PROCESSING", "Processing"),
        ("SHIPPED", "Shipped"),
        ("DELIVERED", "Delivered"),
        ("CANCELLED", "Cancelled"),
    )

    full_name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    shipping_address = models.TextField()
    city = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    state = models.CharField(max_length=100)

    total_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
    )
    discount_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
    )

    # Existing Razorpay fields — preserved
    razorpay_order_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
    )
    razorpay_payment_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
    )

    # Shiprocket shipment and tracking fields
    shiprocket_order_id = models.CharField(
        max_length=100,
        blank=True,
        default="",
    )
    shiprocket_shipment_id = models.CharField(
        max_length=100,
        blank=True,
        default="",
    )
    shiprocket_awb_code = models.CharField(
        max_length=100,
        blank=True,
        default="",
    )
    shiprocket_courier_name = models.CharField(
        max_length=150,
        blank=True,
        default="",
    )
    tracking_url = models.URLField(
        max_length=500,
        blank=True,
        default="",
    )

    payment_status = models.CharField(
        max_length=50,
        default="INITIATED",
    )
    order_status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="PENDING",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return (
            f"Order #{self.id} - {self.full_name} "
            f"(₹{self.total_amount})"
        )


class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        related_name="items",
        on_delete=models.CASCADE,
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    product_name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)

    def subtotal(self):
        return self.price * self.quantity


class Review(models.Model):
    product = models.ForeignKey(
        Product,
        related_name="reviews",
        on_delete=models.CASCADE,
    )
    rating = models.IntegerField(
        choices=[(i, i) for i in range(1, 6)],
    )
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.product.name} ({self.rating}/5)"
